import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { User, Baby, Milestone, NutritionEntry } from '../types';

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  currentBaby: Baby | null;
  setCurrentBaby: (baby: Baby | null) => void;
  language: string;
  setLanguage: (lang: string) => void;
  milestones: Milestone[];
  setMilestones: (milestones: Milestone[]) => void;
  nutritionEntries: NutritionEntry[];
  setNutritionEntries: (entries: NutritionEntry[]) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useLocalStorage<User | null>('chaild_user', null);
  const [currentBaby, setCurrentBaby] = useLocalStorage<Baby | null>('chaild_current_baby', null);
  const [language, setLanguage] = useLocalStorage<string>('chaild_language', 'en');
  const [milestones, setMilestones] = useLocalStorage<Milestone[]>('chaild_milestones', []);
  const [nutritionEntries, setNutritionEntries] = useLocalStorage<NutritionEntry[]>('chaild_nutrition', []);

  return (
    <AppContext.Provider value={{
      user,
      setUser,
      currentBaby,
      setCurrentBaby,
      language,
      setLanguage,
      milestones,
      setMilestones,
      nutritionEntries,
      setNutritionEntries,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
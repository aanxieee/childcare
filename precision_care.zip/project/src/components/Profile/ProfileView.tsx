import React from 'react';
import { useApp } from '../../context/AppContext';
import { Settings, Bell, HelpCircle, Shield, LogOut, Edit, Baby } from 'lucide-react';

export function ProfileView() {
  const { user, currentBaby, setUser, setCurrentBaby } = useApp();

  const handleLogout = () => {
    setUser(null);
    setCurrentBaby(null);
  };

  const calculateAge = (birthDate: string) => {
    const birth = new Date(birthDate);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - birth.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) {
      return `${diffDays} days old`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months !== 1 ? 's' : ''} old`;
    } else {
      const years = Math.floor(diffDays / 365);
      const remainingMonths = Math.floor((diffDays % 365) / 30);
      return `${years} year${years !== 1 ? 's' : ''}${remainingMonths > 0 ? ` ${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}` : ''} old`;
    }
  };

  const menuItems = [
    {
      icon: Settings,
      label: 'Settings',
      description: 'App preferences and account settings',
      action: () => {},
    },
    {
      icon: Bell,
      label: 'Notifications',
      description: 'Manage your notification preferences',
      action: () => {},
    },
    {
      icon: HelpCircle,
      label: 'Help & Support',
      description: 'Get help and contact support',
      action: () => {},
    },
    {
      icon: Shield,
      label: 'Privacy & Security',
      description: 'Manage your privacy settings',
      action: () => {},
    },
  ];

  return (
    <div className="flex-1 overflow-auto p-4 space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl p-6 text-white">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold">
              {user?.name?.charAt(0)?.toUpperCase() || 'U'}
            </span>
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold">{user?.name || 'Parent'}</h2>
            <p className="text-pink-100">Caring parent since {currentBaby?.birthDate ? new Date(currentBaby.birthDate).getFullYear() : 'recently'}</p>
          </div>
          <button className="p-2 bg-white bg-opacity-20 rounded-lg hover:bg-opacity-30 transition-colors">
            <Edit className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Baby Information */}
      {currentBaby && (
        <div className="bg-white rounded-2xl p-6 card-shadow">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">Baby Profile</h3>
            <button className="p-2 text-gray-400 hover:text-pink-500 hover:bg-pink-50 rounded-lg transition-colors">
              <Edit className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
              <Baby className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-800">{currentBaby.name}</h4>
              <p className="text-gray-600">{calculateAge(currentBaby.birthDate)}</p>
              {currentBaby.weight > 0 && (
                <p className="text-sm text-gray-500">Current weight: {currentBaby.weight} kg</p>
              )}
            </div>
          </div>

          {currentBaby.healthNotes && (
            <div className="mt-4 p-3 bg-yellow-50 rounded-xl border border-yellow-200">
              <p className="text-sm font-medium text-yellow-800 mb-1">Health Notes:</p>
              <p className="text-sm text-yellow-700">{currentBaby.healthNotes}</p>
            </div>
          )}
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-4 card-shadow text-center">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <span className="text-xl">📅</span>
          </div>
          <p className="text-2xl font-bold text-blue-600">47</p>
          <p className="text-sm text-gray-600">Days with app</p>
        </div>

        <div className="bg-white rounded-2xl p-4 card-shadow text-center">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <span className="text-xl">✅</span>
          </div>
          <p className="text-2xl font-bold text-green-600">12</p>
          <p className="text-sm text-gray-600">Milestones achieved</p>
        </div>
      </div>

      {/* Menu Items */}
      <div className="bg-white rounded-2xl card-shadow overflow-hidden">
        {menuItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <button
              key={index}
              onClick={item.action}
              className="w-full flex items-center p-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0"
            >
              <div className="p-2 bg-gray-100 rounded-lg mr-4">
                <Icon className="w-5 h-5 text-gray-600" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-gray-800">{item.label}</p>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* App Info */}
      <div className="bg-gray-50 rounded-2xl p-6 text-center">
        <h3 className="font-semibold text-gray-800 mb-2">chAIid-1000 Days</h3>
        <p className="text-sm text-gray-600 mb-4">Version 1.0.0</p>
        <p className="text-xs text-gray-500">
          Your trusted AI companion for the most important 1000 days of your baby's life.
        </p>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="w-full flex items-center justify-center p-4 bg-red-50 text-red-600 rounded-2xl hover:bg-red-100 transition-colors"
      >
        <LogOut className="w-5 h-5 mr-2" />
        Sign Out
      </button>
    </div>
  );
}
import React, { useState } from 'react';
import { HealthProvider } from '../../types';
import { MapPin, Filter, Star, Phone, Navigation, Clock } from 'lucide-react';

export function MapsView() {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedDistance, setSelectedDistance] = useState<string>('all');

  // Sample data - in real app, this would come from an API
  const providers: HealthProvider[] = [
    {
      id: '1',
      name: 'Sunshine Pediatric Clinic',
      type: 'pediatrician',
      address: '123 Health Street, Downtown',
      distance: 1.2,
      rating: 4.8,
      cost: 'medium',
      hours: '8 AM - 6 PM',
      phone: '+1-555-0123',
      coordinates: { lat: 40.7128, lng: -74.0060 },
    },
    {
      id: '2',
      name: 'City Vaccination Center',
      type: 'vaccine_center',
      address: '456 Wellness Ave, Central',
      distance: 2.1,
      rating: 4.6,
      cost: 'low',
      hours: '9 AM - 5 PM',
      phone: '+1-555-0124',
      coordinates: { lat: 40.7589, lng: -73.9851 },
    },
    {
      id: '3',
      name: 'Mother\'s Care Lactation Support',
      type: 'lactation_consultant',
      address: '789 Family Road, Uptown',
      distance: 0.8,
      rating: 4.9,
      cost: 'high',
      hours: '10 AM - 8 PM',
      phone: '+1-555-0125',
      coordinates: { lat: 40.7831, lng: -73.9712 },
    },
    {
      id: '4',
      name: 'New Parents Support Circle',
      type: 'support_group',
      address: '321 Community Center, Eastside',
      distance: 3.5,
      rating: 4.7,
      cost: 'low',
      hours: 'Meetings: Wed 7 PM',
      phone: '+1-555-0126',
      coordinates: { lat: 40.7282, lng: -73.7949 },
    },
  ];

  const typeOptions = [
    { value: 'all', label: 'All Providers' },
    { value: 'pediatrician', label: 'Pediatricians' },
    { value: 'vaccine_center', label: 'Vaccine Centers' },
    { value: 'lactation_consultant', label: 'Lactation Consultants' },
    { value: 'support_group', label: 'Support Groups' },
  ];

  const distanceOptions = [
    { value: 'all', label: 'Any Distance' },
    { value: '1', label: 'Within 1 km' },
    { value: '2', label: 'Within 2 km' },
    { value: '5', label: 'Within 5 km' },
  ];

  const filteredProviders = providers.filter(provider => {
    const typeMatch = selectedType === 'all' || provider.type === selectedType;
    const distanceMatch = selectedDistance === 'all' || provider.distance <= parseFloat(selectedDistance);
    return typeMatch && distanceMatch;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pediatrician':
        return '👩‍⚕️';
      case 'vaccine_center':
        return '💉';
      case 'lactation_consultant':
        return '🤱';
      case 'support_group':
        return '👥';
      default:
        return '🏥';
    }
  };

  const getCostColor = (cost: string) => {
    switch (cost) {
      case 'low':
        return 'text-green-600 bg-green-50';
      case 'medium':
        return 'text-yellow-600 bg-yellow-50';
      case 'high':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="flex-1 overflow-auto">
      {/* Filters */}
      <div className="bg-white border-b border-gray-100 p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Find Healthcare Providers</h2>
          <Filter className="w-5 h-5 text-gray-600" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Provider Type</label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
            >
              {typeOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Distance</label>
            <select
              value={selectedDistance}
              onChange={(e) => setSelectedDistance(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
            >
              {distanceOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Map Placeholder */}
      <div className="h-64 bg-gradient-to-r from-blue-100 to-green-100 flex items-center justify-center m-4 rounded-xl">
        <div className="text-center">
          <MapPin className="w-12 h-12 mx-auto mb-2 text-blue-500" />
          <p className="text-gray-600">Interactive Map View</p>
          <p className="text-sm text-gray-500">Google Maps integration would be here</p>
        </div>
      </div>

      {/* Provider List */}
      <div className="p-4 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800">
          Nearby Providers ({filteredProviders.length})
        </h3>

        {filteredProviders.map((provider) => (
          <div key={provider.id} className="bg-white rounded-xl p-4 card-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center mb-2">
                  <span className="text-2xl mr-3">{getTypeIcon(provider.type)}</span>
                  <div>
                    <h4 className="font-semibold text-gray-800">{provider.name}</h4>
                    <p className="text-sm text-gray-600">{provider.address}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Navigation className="w-4 h-4 mr-1" />
                    {provider.distance} km away
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 mr-1 text-yellow-500" />
                    {provider.rating}
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {provider.hours}
                  </div>
                </div>
              </div>

              <div className={`px-2 py-1 rounded-lg text-xs font-medium ${getCostColor(provider.cost)}`}>
                {provider.cost} cost
              </div>
            </div>

            <div className="flex space-x-2">
              <button className="flex-1 bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600 transition-colors">
                Book Appointment
              </button>
              <button className="flex items-center justify-center p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <Phone className="w-4 h-4" />
              </button>
              <button className="flex items-center justify-center p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <Navigation className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {filteredProviders.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <MapPin className="w-12 h-12 mx-auto mb-3" />
            <p>No providers found matching your criteria.</p>
            <p className="text-sm">Try adjusting your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
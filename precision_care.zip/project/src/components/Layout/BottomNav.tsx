import React from 'react';
import { Home, MapPin, MessageCircle, Camera, Utensils, Music, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const { language } = useApp();

  const tabs = [
    { id: 'dashboard', icon: Home, label: t('dashboard', language as any) },
    { id: 'maps', icon: MapPin, label: t('maps', language as any) },
    { id: 'chat', icon: MessageCircle, label: t('chat', language as any) },
    { id: 'diagnostics', icon: Camera, label: t('diagnostics', language as any) },
    { id: 'nutrition', icon: Utensils, label: t('nutrition', language as any) },
    { id: 'media', icon: Music, label: t('media', language as any) },
    { id: 'profile', icon: User, label: t('profile', language as any) },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-pink-100 px-2 py-2 flex justify-around items-center md:px-4">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-200 min-w-0 flex-1 ${
              isActive
                ? 'bg-pink-100 text-pink-600'
                : 'text-gray-500 hover:text-pink-500 hover:bg-pink-50'
            }`}
          >
            <Icon className="w-5 h-5 mb-1" />
            <span className="text-xs font-medium truncate">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
import React from 'react';
import { Bell, Globe } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';

export function Header() {
  const { language, setLanguage, currentBaby } = useApp();

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिन्दी' },
  ];

  return (
    <div className="bg-white border-b border-pink-100 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-lg">C</span>
        </div>
        <div>
          <h1 className="text-lg font-bold text-gray-800">
            {t('appName', language as any)}
          </h1>
          {currentBaby && (
            <p className="text-sm text-gray-600">
              Hi, {currentBaby.name}'s parent!
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-pink-500"
        >
          {languages.map((lang) => (
            <option key={lang.code} value={lang.code}>
              {lang.label}
            </option>
          ))}
        </select>
        
        <button className="p-2 text-gray-600 hover:text-pink-600 hover:bg-pink-50 rounded-lg transition-colors">
          <Bell className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
import React from 'react';
import { Milestone } from '../../types';
import { useApp } from '../../context/AppContext';
import { Calendar, Heart, Utensils, CheckCircle } from 'lucide-react';

interface MilestoneCardProps {
  milestone: Milestone;
}

export function MilestoneCard({ milestone }: MilestoneCardProps) {
  const { milestones, setMilestones } = useApp();

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'health':
        return <Heart className="w-4 h-4" />;
      case 'nutrition':
        return <Utensils className="w-4 h-4" />;
      default:
        return <Calendar className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'health':
        return 'text-red-500 bg-red-50';
      case 'nutrition':
        return 'text-green-500 bg-green-50';
      default:
        return 'text-blue-500 bg-blue-50';
    }
  };

  const handleMarkComplete = () => {
    const updatedMilestones = milestones.map(m => 
      m.id === milestone.id ? { ...m, completed: true } : m
    );
    setMilestones(updatedMilestones);
  };

  return (
    <div className="border border-gray-100 rounded-xl p-4 hover:bg-gray-50 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center mb-2">
            <div className={`p-2 rounded-lg mr-3 ${getCategoryColor(milestone.category)}`}>
              {getCategoryIcon(milestone.category)}
            </div>
            <div>
              <h4 className="font-medium text-gray-800">{milestone.title}</h4>
              <p className="text-sm text-gray-600">{milestone.description}</p>
            </div>
          </div>
        </div>
        
        {!milestone.completed && (
          <button
            onClick={handleMarkComplete}
            className="ml-4 flex items-center px-3 py-1 text-sm text-green-600 hover:bg-green-50 rounded-lg transition-colors"
          >
            <CheckCircle className="w-4 h-4 mr-1" />
            Complete
          </button>
        )}
      </div>
    </div>
  );
}
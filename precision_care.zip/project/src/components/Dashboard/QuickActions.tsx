import React from 'react';
import { MessageCircle, Camera, Utensils, MapPin, Music, Phone } from 'lucide-react';

interface QuickActionsProps {
  onActionClick?: (action: string) => void;
}

export function QuickActions({ onActionClick }: QuickActionsProps) {
  const actions = [
    {
      id: 'chat',
      icon: MessageCircle,
      label: 'Ask AI',
      color: 'bg-blue-500',
      description: 'Get instant answers',
    },
    {
      id: 'diagnostics',
      icon: Camera,
      label: 'Check Rash',
      color: 'bg-purple-500',
      description: 'Visual analysis',
    },
    {
      id: 'nutrition',
      icon: Utensils,
      label: 'Log Meal',
      color: 'bg-green-500',
      description: 'Track feeding',
    },
    {
      id: 'maps',
      icon: MapPin,
      label: 'Find Care',
      color: 'bg-red-500',
      description: 'Nearby providers',
    },
    {
      id: 'media',
      icon: Music,
      label: 'Lullabies',
      color: 'bg-yellow-500',
      description: 'Soothing sounds',
    },
    {
      id: 'emergency',
      icon: Phone,
      label: 'Emergency',
      color: 'bg-red-600',
      description: 'Quick contacts',
    },
  ];

  return (
    <div className="bg-white rounded-2xl p-6 card-shadow">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {actions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.id}
              onClick={() => onActionClick?.(action.id)}
              className="flex items-center p-4 rounded-xl hover:bg-gray-50 transition-colors text-left"
            >
              <div className={`p-3 rounded-xl ${action.color} mr-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-medium text-gray-800">{action.label}</div>
                <div className="text-sm text-gray-600">{action.description}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
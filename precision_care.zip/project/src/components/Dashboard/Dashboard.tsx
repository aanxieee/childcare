import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';
import { MilestoneCard } from './MilestoneCard';
import { QuickActions } from './QuickActions';
import { BabyStats } from './BabyStats';
import { Milestone } from '../../types';
import { Calendar, Clock, CheckCircle } from 'lucide-react';

export function Dashboard() {
  const { language, currentBaby, milestones, setMilestones } = useApp();

  useEffect(() => {
    if (currentBaby && milestones.length === 0) {
      // Generate sample milestones based on baby's age
      const birthDate = new Date(currentBaby.birthDate);
      const today = new Date();
      const ageInDays = Math.floor((today.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24));

      const sampleMilestones: Milestone[] = [
        {
          id: '1',
          title: 'First Pediatric Visit',
          description: 'Schedule your baby\'s first checkup within the first week',
          ageInDays: 7,
          category: 'health',
          completed: ageInDays > 7,
        },
        {
          id: '2',
          title: 'First Vaccinations',
          description: 'Hepatitis B and other birth vaccines',
          ageInDays: 0,
          category: 'health',
          completed: ageInDays > 0,
        },
        {
          id: '3',
          title: 'Tummy Time',
          description: 'Start short tummy time sessions (2-3 minutes)',
          ageInDays: 14,
          category: 'development',
          completed: ageInDays > 14,
        },
        {
          id: '4',
          title: '2-Month Vaccines',
          description: 'DTaP, IPV, Hib, PCV13, RV vaccines',
          ageInDays: 60,
          category: 'health',
          completed: ageInDays > 60,
        },
        {
          id: '5',
          title: 'Introduction to Solid Foods',
          description: 'Around 4-6 months, introduce first solid foods',
          ageInDays: 120,
          category: 'nutrition',
          completed: ageInDays > 120,
        },
      ];

      setMilestones(sampleMilestones);
    }
  }, [currentBaby, milestones.length, setMilestones]);

  if (!currentBaby) {
    return <div>Loading...</div>;
  }

  const upcomingMilestones = milestones.filter(m => !m.completed).slice(0, 3);
  const completedCount = milestones.filter(m => m.completed).length;

  return (
    <div className="flex-1 overflow-auto p-4 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl p-6 text-white">
        <h2 className="text-xl font-bold mb-2">
          Good morning! ☀️
        </h2>
        <p className="text-pink-100">
          {currentBaby.name} is growing beautifully. Here's what's next on your parenting journey.
        </p>
      </div>

      {/* Baby Stats */}
      <BabyStats baby={currentBaby} />

      {/* Quick Actions */}
      <QuickActions />

      {/* Milestones Overview */}
      <div className="bg-white rounded-2xl p-6 card-shadow">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800">
            {t('milestones.upcoming', language as any)}
          </h3>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center">
              <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
              {completedCount} completed
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1 text-orange-500" />
              {milestones.length - completedCount} pending
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {upcomingMilestones.map((milestone) => (
            <MilestoneCard key={milestone.id} milestone={milestone} />
          ))}
        </div>

        {upcomingMilestones.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-500" />
            <p>All caught up! Great parenting! 🎉</p>
          </div>
        )}
      </div>

      {/* Today's Tips */}
      <div className="bg-blue-50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-3">
          💡 Today's Parenting Tip
        </h3>
        <p className="text-blue-700">
          Establish a consistent bedtime routine early. This helps your baby understand when it's time to sleep and can improve sleep quality for the whole family.
        </p>
      </div>
    </div>
  );
}
import React from 'react';
import { Baby } from '../../types';
import { Calendar, Weight, Clock } from 'lucide-react';

interface BabyStatsProps {
  baby: Baby;
}

export function BabyStats({ baby }: BabyStatsProps) {
  const calculateAge = (birthDate: string) => {
    const birth = new Date(birthDate);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - birth.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) {
      return `${diffDays} days old`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months !== 1 ? 's' : ''} old`;
    } else {
      const years = Math.floor(diffDays / 365);
      const remainingMonths = Math.floor((diffDays % 365) / 30);
      return `${years} year${years !== 1 ? 's' : ''}${remainingMonths > 0 ? ` ${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}` : ''} old`;
    }
  };

  const stats = [
    {
      icon: Calendar,
      label: 'Age',
      value: calculateAge(baby.birthDate),
      color: 'text-blue-500 bg-blue-50',
    },
    {
      icon: Weight,
      label: 'Weight',
      value: baby.weight ? `${baby.weight} kg` : 'Not recorded',
      color: 'text-green-500 bg-green-50',
    },
    {
      icon: Clock,
      label: 'Next Checkup',
      value: 'In 2 weeks',
      color: 'text-purple-500 bg-purple-50',
    },
  ];

  return (
    <div className="bg-white rounded-2xl p-6 card-shadow">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center mr-4">
          <span className="text-white font-bold text-lg">
            {baby.name?.charAt(0)?.toUpperCase() || 'B'}
          </span>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{baby.name}</h3>
          <p className="text-gray-600">Growing strong! 💪</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="flex items-center p-3 rounded-xl border border-gray-100">
              <div className={`p-2 rounded-lg mr-3 ${stat.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{stat.label}</p>
                <p className="font-medium text-gray-800">{stat.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      {baby.healthNotes && (
        <div className="mt-4 p-3 bg-yellow-50 rounded-xl border border-yellow-200">
          <p className="text-sm font-medium text-yellow-800 mb-1">Health Notes:</p>
          <p className="text-sm text-yellow-700">{baby.healthNotes}</p>
        </div>
      )}
    </div>
  );
}
import React, { useState } from 'react';
import { MediaItem } from '../../types';
import { Play, Pause, Heart, Download, Music, BookOpen, Clock } from 'lucide-react';

export function MediaView() {
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'story' | 'lullaby'>('all');

  // Sample media items - in real app, this would come from an API
  const mediaItems: MediaItem[] = [
    {
      id: '1',
      title: 'Twinkle Twinkle Little Star',
      type: 'lullaby',
      duration: 180,
      url: 'https://example.com/twinkle.mp3',
      category: 'Classic Lullabies',
      thumbnail: 'https://images.pexels.com/photos/1666032/pexels-photo-1666032.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
    {
      id: '2',
      title: 'The Three Little Pigs',
      type: 'story',
      duration: 300,
      url: 'https://example.com/three-pigs.mp3',
      category: 'Classic Tales',
      thumbnail: 'https://images.pexels.com/photos/1181605/pexels-photo-1181605.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
    {
      id: '3',
      title: 'Brahms Lullaby',
      type: 'lullaby',
      duration: 240,
      url: 'https://example.com/brahms.mp3',
      category: 'Classical',
      thumbnail: 'https://images.pexels.com/photos/164907/pexels-photo-164907.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
    {
      id: '4',
      title: 'Goldilocks and the Three Bears',
      type: 'story',
      duration: 420,
      url: 'https://example.com/goldilocks.mp3',
      category: 'Classic Tales',
      thumbnail: 'https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
    {
      id: '5',
      title: 'Rock-a-bye Baby',
      type: 'lullaby',
      duration: 200,
      url: 'https://example.com/rockabye.mp3',
      category: 'Traditional',
      thumbnail: 'https://images.pexels.com/photos/1648377/pexels-photo-1648377.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
    {
      id: '6',
      title: 'The Tortoise and the Hare',
      type: 'story',
      duration: 360,
      url: 'https://example.com/tortoise-hare.mp3',
      category: 'Aesop\'s Fables',
      thumbnail: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=1',
    },
  ];

  const filteredItems = mediaItems.filter(item => 
    selectedCategory === 'all' || item.type === selectedCategory
  );

  const togglePlay = (itemId: string) => {
    if (currentlyPlaying === itemId) {
      setCurrentlyPlaying(null);
    } else {
      setCurrentlyPlaying(itemId);
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTypeIcon = (type: string) => {
    return type === 'story' ? BookOpen : Music;
  };

  return (
    <div className="flex-1 overflow-auto p-4 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <Music className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">Stories & Lullabies</h2>
        <p className="text-gray-600">
          Soothing sounds and tales for your little one
        </p>
      </div>

      {/* Category Filter */}
      <div className="bg-white rounded-2xl p-4 card-shadow">
        <div className="flex space-x-2">
          {[
            { value: 'all', label: 'All', icon: Heart },
            { value: 'story' as const, label: 'Stories', icon: BookOpen },
            { value: 'lullaby' as const, label: 'Lullabies', icon: Music },
          ].map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`flex-1 flex items-center justify-center py-3 px-4 rounded-xl transition-colors ${
                  selectedCategory === category.value
                    ? 'bg-pink-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {category.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Media Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map((item) => {
          const TypeIcon = getTypeIcon(item.type);
          const isPlaying = currentlyPlaying === item.id;

          return (
            <div key={item.id} className="bg-white rounded-2xl p-4 card-shadow">
              <div className="flex items-start space-x-4">
                {/* Thumbnail */}
                <div className="relative w-16 h-16 bg-gray-200 rounded-xl overflow-hidden flex-shrink-0">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                    <TypeIcon className="w-6 h-6 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-800 truncate">{item.title}</h3>
                  <p className="text-sm text-gray-600 mb-2">{item.category}</p>
                  
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <Clock className="w-4 h-4 mr-1" />
                    {formatDuration(item.duration)}
                  </div>

                  {/* Controls */}
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => togglePlay(item.id)}
                      className={`flex items-center justify-center w-10 h-10 rounded-full transition-colors ${
                        isPlaying
                          ? 'bg-pink-500 text-white'
                          : 'bg-pink-100 text-pink-600 hover:bg-pink-200'
                      }`}
                    >
                      {isPlaying ? (
                        <Pause className="w-5 h-5" />
                      ) : (
                        <Play className="w-5 h-5" />
                      )}
                    </button>

                    <button className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                      <Heart className="w-4 h-4" />
                    </button>

                    <button className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Progress Bar (when playing) */}
              {isPlaying && (
                <div className="mt-4">
                  <div className="w-full bg-gray-200 rounded-full h-1">
                    <div className="bg-pink-500 h-1 rounded-full w-1/3 transition-all duration-1000"></div>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>1:20</span>
                    <span>{formatDuration(item.duration)}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Recently Played */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recently Played</h3>
        <div className="space-y-3">
          {mediaItems.slice(0, 3).map((item) => (
            <div key={`recent-${item.id}`} className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                {React.createElement(getTypeIcon(item.type), { className: "w-5 h-5 text-purple-500" })}
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-800">{item.title}</p>
                <p className="text-sm text-gray-600">{item.category}</p>
              </div>
              <button
                onClick={() => togglePlay(item.id)}
                className="p-2 text-purple-500 hover:bg-white hover:bg-opacity-50 rounded-lg transition-colors"
              >
                <Play className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <Music className="w-16 h-16 mx-auto mb-4" />
          <p>No items found in this category</p>
        </div>
      )}
    </div>
  );
}
import React, { useState } from 'react';
import { Camera, Upload, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { DiagnosticResult } from '../../types';

export function DiagnosticsView() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DiagnosticResult | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = () => {
    setIsAnalyzing(true);
    setResult(null);

    // Simulate AI analysis
    setTimeout(() => {
      const mockResult: DiagnosticResult = {
        confidence: 0.85,
        diagnosis: 'Mild eczema (atopic dermatitis)',
        riskLevel: 'low',
        advice: 'This appears to be common baby eczema. Keep the area clean and moisturized.',
        recommendations: [
          'Apply fragrance-free moisturizer twice daily',
          'Use gentle, hypoallergenic soap',
          'Avoid tight clothing over the affected area',
          'Monitor for worsening symptoms',
          'Consult pediatrician if no improvement in 3-5 days',
        ],
      };
      setResult(mockResult);
      setIsAnalyzing(false);
    }, 3000);
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'medium':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="flex-1 overflow-auto p-4 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <Camera className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">Visual Health Check</h2>
        <p className="text-gray-600">
          Upload a photo of any skin concern for AI-powered analysis
        </p>
      </div>

      {/* Disclaimer */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <div className="flex items-start">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-yellow-800 mb-1">Important Disclaimer</p>
            <p className="text-sm text-yellow-700">
              This tool provides general guidance only and should not replace professional medical advice. 
              Always consult your pediatrician for proper diagnosis and treatment.
            </p>
          </div>
        </div>
      </div>

      {/* Upload Section */}
      <div className="bg-white rounded-2xl p-6 card-shadow">
        <div className="text-center">
          {!selectedImage ? (
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Upload a clear photo of the affected area</p>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="inline-flex items-center px-6 py-3 bg-pink-500 text-white rounded-xl hover:bg-pink-600 cursor-pointer transition-colors"
              >
                <Camera className="w-5 h-5 mr-2" />
                Choose Photo
              </label>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={selectedImage}
                  alt="Uploaded for analysis"
                  className="max-w-full h-64 object-contain mx-auto rounded-xl"
                />
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setSelectedImage(null)}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Upload Different Photo
                </button>
                <button
                  onClick={analyzeImage}
                  disabled={isAnalyzing}
                  className="flex-1 px-4 py-2 bg-purple-500 text-white rounded-xl hover:bg-purple-600 disabled:opacity-50 transition-colors"
                >
                  {isAnalyzing ? 'Analyzing...' : 'Analyze Photo'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Analysis Progress */}
      {isAnalyzing && (
        <div className="bg-white rounded-2xl p-6 card-shadow">
          <div className="flex items-center justify-center space-x-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-500"></div>
            <p className="text-gray-600">AI is analyzing the image...</p>
          </div>
          <div className="mt-4 space-y-2 text-sm text-gray-500">
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Processing image quality...
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Identifying skin patterns...
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Comparing with medical database...
            </div>
          </div>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="bg-white rounded-2xl p-6 card-shadow space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-800">Analysis Results</h3>
            <div className={`px-3 py-1 rounded-full text-sm font-medium border ${getRiskLevelColor(result.riskLevel)}`}>
              {result.riskLevel.toUpperCase()} RISK
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600 mb-1">Likely Diagnosis:</p>
              <p className="font-medium text-gray-800">{result.diagnosis}</p>
              <p className="text-sm text-gray-500">Confidence: {(result.confidence * 100).toFixed(0)}%</p>
            </div>

            <div>
              <p className="text-sm text-gray-600 mb-2">General Advice:</p>
              <p className="text-gray-700">{result.advice}</p>
            </div>

            <div>
              <p className="text-sm text-gray-600 mb-2">Recommendations:</p>
              <ul className="space-y-2">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            {result.riskLevel === 'high' && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <div className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-red-600 mr-3 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-800 mb-1">Urgent Care Recommended</p>
                    <p className="text-sm text-red-700">
                      Please consult a healthcare provider within 24 hours or seek immediate medical attention if symptoms worsen.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <button className="w-full bg-pink-500 text-white py-3 rounded-xl hover:bg-pink-600 transition-colors">
            Find Nearby Pediatricians
          </button>
        </div>
      )}
    </div>
  );
}
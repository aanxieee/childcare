import React, { useState } from 'react';
import { Baby, User } from '../../types';
import { useApp } from '../../context/AppContext';
import { t } from '../../utils/translations';
import { Calendar, Weight, FileText, Baby as BabyIcon } from 'lucide-react';

export function OnboardingWizard() {
  const { language, setUser, setCurrentBaby } = useApp();
  const [formData, setFormData] = useState({
    name: '',
    birthDate: '',
    weight: '',
    healthNotes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const baby: Baby = {
      id: Date.now().toString(),
      name: formData.name,
      birthDate: formData.birthDate,
      weight: parseFloat(formData.weight) || 0,
      healthNotes: formData.healthNotes,
    };

    const user: User = {
      id: Date.now().toString(),
      name: `${baby.name}'s Parent`,
      email: '',
      language: language,
      babies: [baby],
    };

    setUser(user);
    setCurrentBaby(baby);
  };

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <BabyIcon className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">
            {t('onboarding.title', language as any)}
          </h1>
          <p className="text-gray-600">
            {t('welcome', language as any)}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white rounded-2xl p-6 card-shadow">
            <div className="space-y-4">
              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <BabyIcon className="w-4 h-4 mr-2 text-pink-500" />
                  {t('onboarding.babyName', language as any)}
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                  placeholder="Enter baby's name"
                />
              </div>

              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="w-4 h-4 mr-2 text-blue-500" />
                  {t('onboarding.birthDate', language as any)}
                </label>
                <input
                  type="date"
                  required
                  value={formData.birthDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, birthDate: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <Weight className="w-4 h-4 mr-2 text-green-500" />
                  {t('onboarding.weight', language as any)}
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.weight}
                  onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                  placeholder="0.0"
                />
              </div>

              <div>
                <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                  <FileText className="w-4 h-4 mr-2 text-purple-500" />
                  {t('onboarding.healthNotes', language as any)}
                </label>
                <textarea
                  rows={3}
                  value={formData.healthNotes}
                  onChange={(e) => setFormData(prev => ({ ...prev, healthNotes: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent resize-none"
                  placeholder="Any health concerns or notes..."
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-4 rounded-xl font-semibold hover:from-pink-600 hover:to-purple-600 transition-all duration-200 card-shadow"
          >
            {t('onboarding.continue', language as any)}
          </button>
        </form>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { ChatMessage } from '../../types';
import { Send, Mic, MicOff } from 'lucide-react';

export function ChatView() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: 'Hello! I\'m your AI parenting assistant. How can I help you today?',
      sender: 'ai',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(inputText),
        sender: 'ai',
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  const getAIResponse = (question: string): string => {
    const responses = {
      'solids': 'Most babies are ready for solid foods around 4-6 months. Signs include: sitting up with support, showing interest in your food, and losing the tongue-thrust reflex. Start with single-ingredient purees like rice cereal, banana, or sweet potato.',
      'sleep': 'Newborns sleep 14-17 hours per day in short periods. By 3-6 months, many babies can sleep 6-8 hour stretches. Establish a bedtime routine with dim lights, gentle sounds, and consistent timing.',
      'crying': 'Babies cry for many reasons: hunger, tiredness, discomfort, overstimulation, or just needing comfort. Try the 5 S\'s: Swaddling, Shushing, Swinging, Sucking, and Side/stomach position (while awake).',
      'feeding': 'Newborns typically feed every 2-3 hours. Breastfed babies may feed more frequently. Look for hunger cues like rooting, sucking motions, or bringing hands to mouth rather than waiting for crying.',
    };

    const lowerQuestion = question.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (lowerQuestion.includes(key)) {
        return response;
      }
    }

    return 'That\'s a great question! While I can provide general guidance, it\'s always best to consult with your pediatrician for personalized advice about your baby\'s specific needs. Is there anything specific about feeding, sleep, or development you\'d like to know more about?';
  };

  const toggleVoiceInput = () => {
    setIsListening(!isListening);
    // In a real app, this would start/stop speech recognition
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-100 p-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex items-center justify-center mr-3">
            <span className="text-white font-bold">AI</span>
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">AI Assistant</h3>
            <p className="text-sm text-green-600">● Online</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-2xl ${
                message.sender === 'user'
                  ? 'bg-pink-500 text-white'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <p className="text-sm">{message.text}</p>
              <p
                className={`text-xs mt-1 ${
                  message.sender === 'user' ? 'text-pink-100' : 'text-gray-500'
                }`}
              >
                {formatTime(message.timestamp)}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Suggestions */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex flex-wrap gap-2 mb-4">
          {['When to start solids?', 'Sleep schedule tips', 'Why is baby crying?', 'Feeding frequency'].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setInputText(suggestion)}
              className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
            >
              {suggestion}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask me anything about your baby..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 pr-12"
            />
            <button
              onClick={toggleVoiceInput}
              className={`absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-lg transition-colors ${
                isListening ? 'text-red-500 bg-red-50' : 'text-gray-400 hover:text-pink-500'
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          </div>
          <button
            onClick={handleSendMessage}
            disabled={!inputText.trim()}
            className="p-3 bg-pink-500 text-white rounded-xl hover:bg-pink-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        {isListening && (
          <div className="mt-2 flex items-center justify-center text-red-500">
            <div className="animate-pulse flex items-center">
              <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
              Listening...
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
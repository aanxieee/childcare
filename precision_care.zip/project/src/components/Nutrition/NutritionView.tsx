import React, { useState } from 'react';
import { NutritionEntry } from '../../types';
import { useApp } from '../../context/AppContext';
import { Plus, Milk, Baby, Utensils, Calendar, TrendingUp } from 'lucide-react';

export function NutritionView() {
  const { nutritionEntries, setNutritionEntries } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [newEntry, setNewEntry] = useState({
    type: 'breastfeed' as 'breastfeed' | 'bottle' | 'solid',
    amount: '',
    unit: 'minutes',
    notes: '',
  });

  const handleAddEntry = () => {
    if (!newEntry.amount) return;

    const entry: NutritionEntry = {
      id: Date.now().toString(),
      type: newEntry.type,
      amount: parseFloat(newEntry.amount),
      unit: newEntry.unit,
      timestamp: new Date().toISOString(),
      notes: newEntry.notes,
    };

    setNutritionEntries([...nutritionEntries, entry]);
    setNewEntry({ type: 'breastfeed', amount: '', unit: 'minutes', notes: '' });
    setShowAddForm(false);
  };

  const getTodayEntries = () => {
    const today = new Date().toDateString();
    return nutritionEntries.filter(entry => 
      new Date(entry.timestamp).toDateString() === today
    );
  };

  const getEntryIcon = (type: string) => {
    switch (type) {
      case 'breastfeed':
        return <Baby className="w-5 h-5 text-pink-500" />;
      case 'bottle':
        return <Milk className="w-5 h-5 text-blue-500" />;
      case 'solid':
        return <Utensils className="w-5 h-5 text-green-500" />;
      default:
        return <Utensils className="w-5 h-5 text-gray-500" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'breastfeed':
        return 'Breastfeed';
      case 'bottle':
        return 'Bottle';
      case 'solid':
        return 'Solid Food';
      default:
        return type;
    }
  };

  const todayEntries = getTodayEntries();
  const totalFeedings = todayEntries.length;
  const lastFeeding = todayEntries[todayEntries.length - 1];

  return (
    <div className="flex-1 overflow-auto p-4 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-4 card-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Today's Feedings</p>
              <p className="text-2xl font-bold text-gray-800">{totalFeedings}</p>
            </div>
            <div className="p-3 bg-pink-100 rounded-xl">
              <TrendingUp className="w-6 h-6 text-pink-500" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 card-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Last Feeding</p>
              <p className="text-sm font-medium text-gray-800">
                {lastFeeding 
                  ? new Date(lastFeeding.timestamp).toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })
                  : 'No entries'
                }
              </p>
            </div>
            <div className="p-3 bg-blue-100 rounded-xl">
              <Calendar className="w-6 h-6 text-blue-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Add Entry Button */}
      <button
        onClick={() => setShowAddForm(true)}
        className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-4 rounded-2xl font-semibold hover:from-pink-600 hover:to-purple-600 transition-all duration-200 card-shadow flex items-center justify-center"
      >
        <Plus className="w-5 h-5 mr-2" />
        Add Feeding Entry
      </button>

      {/* Add Entry Form */}
      {showAddForm && (
        <div className="bg-white rounded-2xl p-6 card-shadow">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">New Feeding Entry</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 'breastfeed', label: 'Breastfeed', icon: Baby },
                  { value: 'bottle', label: 'Bottle', icon: Milk },
                  { value: 'solid', label: 'Solid', icon: Utensils },
                ].map((option) => {
                  const Icon = option.icon;
                  return (
                    <button
                      key={option.value}
                      onClick={() => {
                        setNewEntry(prev => ({ 
                          ...prev, 
                          type: option.value as any,
                          unit: option.value === 'breastfeed' ? 'minutes' : 'ml'
                        }));
                      }}
                      className={`p-3 rounded-xl border text-center transition-colors ${
                        newEntry.type === option.value
                          ? 'border-pink-500 bg-pink-50 text-pink-700'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="w-5 h-5 mx-auto mb-1" />
                      <span className="text-sm font-medium">{option.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
                <input
                  type="number"
                  value={newEntry.amount}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, amount: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                <select
                  value={newEntry.unit}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, unit: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                >
                  {newEntry.type === 'breastfeed' ? (
                    <option value="minutes">minutes</option>
                  ) : (
                    <>
                      <option value="ml">ml</option>
                      <option value="oz">oz</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Notes (optional)</label>
              <textarea
                rows={2}
                value={newEntry.notes}
                onChange={(e) => setNewEntry(prev => ({ ...prev, notes: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 resize-none"
                placeholder="Any additional notes..."
              />
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowAddForm(false)}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddEntry}
                className="flex-1 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
              >
                Add Entry
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Today's Entries */}
      <div className="bg-white rounded-2xl p-6 card-shadow">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Today's Feeding Log</h3>
        
        {todayEntries.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Utensils className="w-12 h-12 mx-auto mb-3" />
            <p>No feedings logged today</p>
            <p className="text-sm">Add your first entry above</p>
          </div>
        ) : (
          <div className="space-y-3">
            {todayEntries.reverse().map((entry) => (
              <div key={entry.id} className="flex items-center justify-between p-3 border border-gray-100 rounded-lg">
                <div className="flex items-center">
                  {getEntryIcon(entry.type)}
                  <div className="ml-3">
                    <p className="font-medium text-gray-800">{getTypeLabel(entry.type)}</p>
                    <p className="text-sm text-gray-600">
                      {entry.amount} {entry.unit}
                      {entry.notes && ` • ${entry.notes}`}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-gray-500">
                  {new Date(entry.timestamp).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Weekly Summary */}
      {nutritionEntries.length > 0 && (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">This Week's Summary</h3>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-blue-600">{nutritionEntries.length}</p>
              <p className="text-sm text-gray-600">Total Feedings</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-600">
                {(nutritionEntries.length / 7).toFixed(1)}
              </p>
              <p className="text-sm text-gray-600">Avg per Day</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
export interface Baby {
  id: string;
  name: string;
  birthDate: string;
  weight: number;
  healthNotes: string;
  avatar?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  language: string;
  babies: Baby[];
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  ageInDays: number;
  category: 'health' | 'development' | 'nutrition';
  completed: boolean;
  dueDate?: string;
}

export interface HealthProvider {
  id: string;
  name: string;
  type: 'pediatrician' | 'vaccine_center' | 'lactation_consultant' | 'support_group';
  address: string;
  distance: number;
  rating: number;
  cost: 'low' | 'medium' | 'high';
  hours: string;
  phone: string;
  website?: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface NutritionEntry {
  id: string;
  type: 'breastfeed' | 'bottle' | 'solid';
  amount: number;
  unit: string;
  timestamp: string;
  notes?: string;
}

export interface MediaItem {
  id: string;
  title: string;
  type: 'story' | 'lullaby';
  duration: number;
  url: string;
  thumbnail?: string;
  category: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
  type?: 'text' | 'voice' | 'image';
}

export interface DiagnosticResult {
  confidence: number;
  diagnosis: string;
  riskLevel: 'low' | 'medium' | 'high';
  advice: string;
  recommendations: string[];
}
export const translations = {
  en: {
    appName: 'chAIid-1000 Days',
    welcome: 'Welcome to your parenting companion',
    dashboard: 'Dashboard',
    maps: 'Find Care',
    chat: 'Ask AI',
    diagnostics: 'Visual Check',
    nutrition: 'Nutrition',
    media: 'Stories & Songs',
    profile: 'Profile',
    onboarding: {
      title: 'Let\'s get started!',
      babyName: 'Baby\'s Name',
      birthDate: 'Birth Date',
      weight: 'Current Weight (kg)',
      healthNotes: 'Health Notes (optional)',
      continue: 'Continue',
      skip: 'Skip for now',
    },
    milestones: {
      upcoming: 'Upcoming Milestones',
      overdue: 'Overdue',
      completed: 'Completed',
      markComplete: 'Mark Complete',
    },
    chat: {
      placeholder: 'Ask me anything about your baby...',
      send: 'Send',
      listening: 'Listening...',
      voiceInput: 'Voice Input',
    },
    nutrition: {
      addEntry: 'Add Entry',
      breastfeed: 'Breastfeed',
      bottle: 'Bottle',
      solid: 'Solid Food',
      amount: 'Amount',
      notes: 'Notes',
      todayTotal: 'Today\'s Total',
    },
  },
  hi: {
    appName: 'चाईड-1000 दिन',
    welcome: 'आपके पैरेंटिंग साथी में आपका स्वागत है',
    dashboard: 'डैशबोर्ड',
    maps: 'देखभाल खोजें',
    chat: 'AI से पूछें',
    diagnostics: 'विज़ुअल जांच',
    nutrition: 'पोषण',
    media: 'कहानियां और गाने',
    profile: 'प्रोफ़ाइल',
    onboarding: {
      title: 'चलिए शुरू करते हैं!',
      babyName: 'बच्चे का नाम',
      birthDate: 'जन्म तिथि',
      weight: 'वर्तमान वजन (किलोग्राम)',
      healthNotes: 'स्वास्थ्य टिप्पणियां (वैकल्पिक)',
      continue: 'जारी रखें',
      skip: 'अभी के लिए छोड़ें',
    },
    milestones: {
      upcoming: 'आगामी मील के पत्थर',
      overdue: 'देरी से',
      completed: 'पूर्ण',
      markComplete: 'पूर्ण के रूप में चिह्नित करें',
    },
    chat: {
      placeholder: 'अपने बच्चे के बारे में कुछ भी पूछें...',
      send: 'भेजें',
      listening: 'सुन रहा हूं...',
      voiceInput: 'आवाज इनपुट',
    },
    nutrition: {
      addEntry: 'प्रविष्टि जोड़ें',
      breastfeed: 'स्तनपान',
      bottle: 'बोतल',
      solid: 'ठोस भोजन',
      amount: 'मात्रा',
      notes: 'टिप्पणियां',
      todayTotal: 'आज की कुल',
    },
  },
};

export type Language = keyof typeof translations;

export function t(key: string, language: Language = 'en'): string {
  const keys = key.split('.');
  let value: any = translations[language];
  
  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = value[k];
    } else {
      // Fallback to English if translation not found
      value = translations.en;
      for (const fallbackKey of keys) {
        if (value && typeof value === 'object' && fallbackKey in value) {
          value = value[fallbackKey];
        } else {
          return key; // Return key if no translation found
        }
      }
      break;
    }
  }
  
  return typeof value === 'string' ? value : key;
}
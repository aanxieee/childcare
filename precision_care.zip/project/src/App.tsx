import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { OnboardingWizard } from './components/Onboarding/OnboardingWizard';
import { Header } from './components/Layout/Header';
import { BottomNav } from './components/Layout/BottomNav';
import { Dashboard } from './components/Dashboard/Dashboard';
import { MapsView } from './components/Maps/MapsView';
import { ChatView } from './components/Chat/ChatView';
import { DiagnosticsView } from './components/Diagnostics/DiagnosticsView';
import { NutritionView } from './components/Nutrition/NutritionView';
import { MediaView } from './components/Media/MediaView';
import { ProfileView } from './components/Profile/ProfileView';

function AppContent() {
  const { user } = useApp();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (!user) {
    return <OnboardingWizard />;
  }

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'maps':
        return <MapsView />;
      case 'chat':
        return <ChatView />;
      case 'diagnostics':
        return <DiagnosticsView />;
      case 'nutrition':
        return <NutritionView />;
      case 'media':
        return <MediaView />;
      case 'profile':
        return <ProfileView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen gradient-bg flex flex-col">
      <Header />
      <main className="flex-1 flex flex-col pb-20">
        {renderActiveView()}
      </main>
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;